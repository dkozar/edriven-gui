﻿=== Blue-Glass for Vista Cursor Set ===

By: Vlasta (http://www.rw-designer.com/user/1)

Download: http://www.rw-designer.com/cursor-set/blueglass-vista

Author's decription:

A cursor set designed to be used on Windows Vista together with the glass theme.

The cursors have built-in shadows => turn off automatic cursor shadow generation if you are using Vista Beta 2.

Note: the cursor set is not complete yet. More cursors will be added later.

==========

License: Creative Commons - Attribution

You are free:

* To Share - To copy, distribute and transmit the work.
* To Remix - To adapt the work.

Under the following conditions:

* Attribution - You must attribute the work in the manner specified
  by the author or licensor (but not in any way that suggests that
  they endorse you or your use of the work). For example, if you are
  making the work available on the Internet, you must link to the
  original source.