﻿using eDriven.Core.Util;
using eDriven.Tests.Core.EventDispatcher;
using UnityEngine;
using Event=eDriven.Core.Events.Event;

public class EventListenerScript3 : MonoBehaviour
{
    // ReSharper disable UnusedMember.Local
    void Start()
    // ReSharper restore UnusedMember.Local
    {
        #region Obsolete

//// find cube
        //GameObject go = GameObject.Find("EventDispatcher");

        //// reference dispatcher
        //EventDispatcherScript2 script = go.GetComponent<EventDispatcherScript2>();

        #endregion

        EventDispatcherScript3 script = ComponentUtil.ReferenceScript<EventDispatcherScript3>("EventDispatcher");

        #region Using AddEventListener method

        // subscribe to event
        //script.AddEventListener(EventDispatcherScript.OBJECT_CLICKED, OnObjectClicked);

        #region Anonymous version

        //script.AddEventListener(EventDispatcherScript.OBJECT_CLICKED, delegate(Event e)
        //{
        //    GameObject target = ((GameObject)e.Target);
        //    Debug.Log(string.Format(@"EventListenerScript3: event received: {0}", e));
        //    Debug.Log(string.Format(@"Position: {0}", ((CustomEvent)e).Position));
        //    Debug.Log(string.Format(@"target.name: {0}", target.name));

        //    #region Action

        //    // make action on this
        //    iTween.PunchPosition(gameObject, new Vector3(0, 1f, 0), 2);
        //    iTween.ColorTo(gameObject, Color.green, 1);

        //    // make action on Target (originator)
        //    iTween.PunchPosition(target, new Vector3(0, -1f, 0), 2);
        //    iTween.ColorTo(target, Color.red, 1);

        //    // play audio
        //    AudioSource audioSource = GetComponent<AudioSource>();
        //    audioSource.Play();

        //    #endregion
        //});

        #endregion
        
        #endregion

        #region Using multicast delegate

        // Note: Gizmos not implemented for multicast delegate subscription

        // subscribe to event
        script.ObjectClicked += OnObjectClicked;

        #region Anonymous version

        //script.ObjectClicked += delegate(Event e)
        //{
        //    GameObject target = ((GameObject)e.Target);
        //    Debug.Log(string.Format(@"EventListenerScript3: event received: {0}", e));
        //    Debug.Log(string.Format(@"Position: {0}", ((CustomEvent)e).Position));
        //    Debug.Log(string.Format(@"target.name: {0}", target.name));

        //    #region Action

        //    // make action on this
        //    iTween.PunchPosition(gameObject, new Vector3(0, 1f, 0), 2);
        //    iTween.ColorTo(gameObject, Color.green, 1);

        //    // make action on Target (originator)
        //    iTween.PunchPosition(target, new Vector3(0, -1f, 0), 2);
        //    iTween.ColorTo(target, Color.red, 1);

        //    // play audio
        //    AudioSource audioSource = GetComponent<AudioSource>();
        //    audioSource.Play();

        //    #endregion
        //};

        #endregion

        #endregion
    }

    private void OnObjectClicked(Event e)
    {
        GameObject target = ((GameObject)e.Target);
        Debug.Log(string.Format(@"EventListenerScript3: event received: {0}", e));
        Debug.Log(string.Format(@"Position: {0}", ((CustomEvent)e).Position));
        Debug.Log(string.Format(@"target.name: {0}", target.name));

        #region Action

        // make action on this
        iTween.PunchPosition(gameObject, new Vector3(0, 1f, 0), 2);
        iTween.ColorTo(gameObject, Color.green, 1);

        // make action on Target (originator)
        iTween.PunchPosition(target, new Vector3(0, -1f, 0), 2);
        iTween.ColorTo(target, Color.red, 1);

        // play audio
        AudioSource audioSource = GetComponent<AudioSource>();
        audioSource.Play();

        #endregion
    }
}